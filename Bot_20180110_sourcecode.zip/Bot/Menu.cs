﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bot.Core
{
    public class Node
    {
        public string CweCommand { get; set; }
        public string AdditionalOptions { get; set; }
    }

    public class Menu:Node
    {
        public Menu()
        {
            Nodes = new List<Node>();
        }
        public Header Header { get; set; }
        public Disclaimer Disclaimer { get; set; }
        public Footer Footer { get; set; }
        public List<Node> Nodes { get; set; }
    }

    public class LanguageNode : Menu
    {
        public LanguageNode()
        {
            Languages = new List<string>();
            LanguagesAltText = new List<string>();
        }
        public List<string> Languages { get; set; }
        public List<string> LanguagesAltText { get; set; }
        public bool UseEnglishLanguageName { get; set; }
    }

    public class SubMenuNode : Menu
    {
        public SubMenuNode()
        {
            Keywords = new List<string>();
        }
        public List<string> Keywords { get; set; }
        public Option Option { get; set; }
        public bool DisplayChosenText { get; set; }
        public bool DisplaySelectionText { get; set; }
        public bool DisableGoBackOption { get; set; }
        public bool HideMenu { get; set; }
        public bool HideMenuNumbers { get; set; } 
    }     
  
    public class InformationalNode:Node
    {
        public Header Header { get; set; }
        public Disclaimer Disclaimer { get; set; }
        public bool DisplayConnectionText { get; set; }
        public bool DisableGoBackOption { get; set; }
    }

    public class LoopbackNode : Node
    {
        public Option Option { get; set; }
    }

    public class HandoffNode : Node
    {
        public HandoffNode()
        {
            Keywords = new List<string>();
        }
        public Header Header { get; set; }
        public Disclaimer Disclaimer { get; set; }
        public Option Option { get; set; }
        public Queue Queue { get; set; }
        public List<string> Keywords { get; set; }
        public bool ShowConfirmation { get; set; }
        public bool DisplayHoursOfOperation { get; set; }
    }

    #region Parts
    public class TextBase
    {
        public string Text { get; set; }
        public string Format { get; set; }
    }
    public class Header : TextBase { }
    public class Disclaimer : TextBase { }
    public class Footer : TextBase { }
    public class Option : TextBase { }

   

    #endregion


}
