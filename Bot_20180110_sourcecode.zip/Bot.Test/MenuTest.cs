﻿using System;
using Bot.Core;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Bot.Test
{
    [TestClass]
    public class MenuTest
    {
        [TestMethod]
        public void TestType()
        {
            var lang = new LanguageNode();
            lang.Header = new Header { Text = "Please select a language" };
            var sub1 = new SubMenuNode();
            sub1.Header = new Header { Text = "Password Rest" };
            var agent = new HandoffNode();
            agent.Header = new Header { Text = "Chat with Agent" };
            sub1.Nodes.Add(agent);
            var sub2 = new SubMenuNode();
            sub2.Header = new Header { Text = "OutLook" };           
            var info = new InformationalNode();
            info.Header = new Header { Text = "Pleae go to this link for help" };
            sub2.Nodes.Add(info);
            lang.Nodes.Add(sub1);
            lang.Nodes.Add(sub2);           

            Assert.IsTrue(lang is LanguageNode);
            Assert.IsTrue(lang.Nodes[0] is SubMenuNode);
            var node = lang.Nodes[0] as SubMenuNode;
            Assert.IsTrue(node.Nodes[0] is HandoffNode);

            Assert.IsTrue(lang.Nodes[1] is SubMenuNode);
            var node1 = lang.Nodes[1] as SubMenuNode;
            Assert.IsTrue(node1.Nodes[0] is InformationalNode);
        }
    }
}
