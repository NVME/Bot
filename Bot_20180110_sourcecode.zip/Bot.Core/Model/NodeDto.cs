﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Bot.COMM
{

    /// <summary>
    ///  A DTO object to have all feilds from all node types.
    /// </summary>
    [DataContract]
    public class NodeDto:Dto
    {
        [DataMember]
        public int Id {get; set; }
        // public int ParentId { get; set; }
        [DataMember]
        public string HeaderText { get; set; }//Text displayed at the top of the menu. (optional)
        //public string HeaderTextFormat { get; set; }//CSS formatting string for the text. (optional)
        //public string DisclaimerText { get; set; }//Text displayed in smaller font under the header. (optional)
        //public string DisclaimerTextFormat { get; set; }//CSS formatting string for the text. (optional)
        //public string FooterText { get; set; }//Text displayed below the menu. (optional)
        //public string FooterTextFormat { get; set; }//CSS formatting string for the text. (optional)
        [DataMember]
        public List<String> Keywords { get; set; }//Keywords that will select this node from a menu. (optional)
        //public string OptionText { get; set; }//The text displayed in a menu containing this node.
        //public string OptionTextFormat { get; set; }//CSS formatting string for the text. (optional)
        //public bool DisplayChosenText { get; set; }//Determines if the standard "You have chosen the xxx option" text is shown. Default is true.
        //public bool DisplaySelectionText { get; set; }//Determines if the selection instruction text is displayed. Default is true.
        //public bool DisableGoBackOption { get; set; }//Determines if the standard "Go back to the previous level" option is shown (if applicable). Default is false.
        [DataMember]
        public bool HideMenu { get; set; }//Determines if the menu options are shown. Default is false.
        //public bool HideMenuNumbers { get; set; }//Determines if numbers appear before menu options. Default is false.
        //public string CweCommand { get; set; }//Data to send to a CWE if present. (optional)
        //public string AdditionalOptions { get; set; }//For additional options from future enhancements.

        //public int Queue { get; set; }//The queue to connect to.
        //public string QueueName { get; set; }//The name of the queue to be connected to.
        //public bool ShowConfirmation { get; set; }//Determines if a confirmation screen is shown before connecting. Default is true.
        //public bool DisplayHoursOfOperation { get; set; }//Determines if the queue's hours of operation are added to the OptionText. Default is false.

        //public List<string> Languages { get; set; }//List of languages. Might be taken from bot setup. Might be the place to specify the bot's languages.
        //public List<string> LanguageAltText { get; set; }//The label for each langauge in the menu if the language name is not desired.
        //public bool UseEnglishLanguageName { get; set; }//Displays the English name for each language in the menu instead of the localized name.






    }
}
