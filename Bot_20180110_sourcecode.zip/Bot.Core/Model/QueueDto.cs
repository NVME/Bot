﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Bot.COMM
{
    [DataContract]
    public class QueueDto:Dto
    {
        [DataMember]
        public int Id { get; set; }
        [DataMember]
        public int NodeId { get; set; } // relation(fk) with Handoff node
        [DataMember]
        public string Name { get; set; }
        //public string CustomerId { get; set; }
        //public int HoursOfOperation { get; set; }
        //public List<string> SupportedLanguages { get; set; }
        //public string SIP { get; set; }
        //public string  BackupSIP { get; set; }

    }
}
