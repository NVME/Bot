﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bot;
using Bot.COMM;
using Bot.Core;

namespace Bot.Worker
{
    public static class MapperExtension
    {
        public static BotProfile ToBotProfile(this BotProfileDto dto)
        {
            if (dto == null) throw new ApplicationException("null reference object");
            return new InteractiveResponse { Id=dto.Id,Name=dto.Name};
        }

        public static Node ToNode(this NodeDto dto)
        {
            if (dto == null) throw new ApplicationException("null reference object");
            return new Node();
        }

        public static Queue ToQueue(this QueueDto dto)
        {
            if (dto == null) throw new ApplicationException("null reference object");
            return new Queue {  Name = dto.Name };
        }
    }
}
