﻿namespace Bot.COMM
{
    public class Notification
    {
        public string Message { get; set; }
    }
}