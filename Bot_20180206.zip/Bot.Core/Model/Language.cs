﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bot.COMM
{
   public  class Language
    {
        public int LanguageId { get; set; }
        public string  EnglishName { get; set; }
        public string LocalName { get; set; }
        public string LanguageCode { get; set; }
        public List<string> keywords { get; set; }
    }

    public class LanguageOption
    {
        public Language Language { get; set; }
        public int NodeId { get; set; }
    }
}
