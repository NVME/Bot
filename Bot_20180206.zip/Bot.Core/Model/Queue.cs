﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bot.COMM
{
    public class Queue
    {
        public int QueueId { get; set; }
        public string EnglishName { get; set; }
        public string CustomerId { get; set; }
        public HoursOfOperation HoursOfOperation { get; set; }
        public List<string> SupportedLanguages { get; set; } // list of language code
    }
    public class Avaya : Queue
    {
        public string SIP { get; set; }
        public string BackupSIP { get; set; }
    }

    public class ServiceNow : Queue { }

    public class LocalQueueName
    {
        public string  LanguageCode { get; set; }
        public string QueueName { get; set; }
    }
    
    public class GlobalQueueName
    {
        public List<LocalQueueName> QueueNames { get; set; }
    }

    public class HoursOfOperation
    {
        public string TimeZone { get; set; }
        public List<WorkDay> WorkDays { get; set; } // seven days 

    }
    public class WorkShift
    {
        public string  StartDateTimeUTC { get; set; }
        public string EndDateTimeUTC { get; set; }
    }

    public class WorkDay
    {
        public int DayOfWeek { get; set; }
        public Choice Type { get; set; }
        public List<WorkShift> WorkShifts { get; set; }
    }

    public enum Choice
    {
        All24Hours =1,
        Custom=2,
        Closed=3
    }
}
