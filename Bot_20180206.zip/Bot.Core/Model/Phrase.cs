﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bot.COMM
{
    public class GlobalPhrase
    {
        public string Id { get; set; }

        public List<LocalPhrase> Phrases { get; set; }
    }

    public class LocalPhrase
    {
       public string LanguageCode { get; set; }
       public string Text { get; set; }
    }
}
