﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bot.Core
{
    
    public class Queue
    {
        public string Name { get; set; }
        public string CustomerId { get; set; }
        public int HoursOfOperation { get; set; }
        public List<string> SupportedLanguages { get; set; } 
    }
    public class Avaya:Queue
    {
        public string SIP { get; set; }
        public string BackupSIP { get; set; }
    }

    public class ServiceNow : Queue { }
}
