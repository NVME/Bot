﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bot.COMM
{
  public  class CreateBotRequest
    {
        public BotProfile BotProfile { get; set; }
        public Menu Menu { get; set; }
    }
}
