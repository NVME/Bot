﻿using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Bot.Worker
{
    [ServiceContract]
    public interface IBotService
    {
        [OperationContract]
        void StartBotService(BotEndpoint botEndpoint);
        [OperationContract]
        void StopBotService(BotEndpoint botEndpoint);
      
    }
}

   
