﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Collections;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Cors;
using Bot.COMM;


namespace Bot.Master
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    public class BotController:ApiController
    {
        
        [HttpPost]
        public void Create(CreateBotRequest request)
        {
            var profile = request.BotProfile;
            var menu = request.Menu;
            Master.Create(profile,menu);
        }
       
        [HttpPost]
        public void Start(BotProfile bot)
        {
            Master.Start(bot);
        }
        
        [HttpPost]
        public void Notify(Notification notification)
        {
            Console.WriteLine("Message from bot:"+ notification.message);
        }
        
        [HttpGet]
        public string Hello()
        {
            return "OK";
        }
    }

    
}
