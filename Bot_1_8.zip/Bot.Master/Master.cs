﻿using Bot.COMM;
using Bot.Worker;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace Bot.Master
{
  public  class Master
    {
        private static Dictionary<int, string> processList = new Dictionary<int, string>();

        public static void Create(BotProfile bot,Menu menu=null)
        {
            Console.WriteLine("create a bot");
            using (Process botProcess = new Process())
            {
                botProcess.StartInfo = new ProcessStartInfo("bot.exe");
                botProcess.StartInfo.Arguments = bot.Name;
                //ssnavBotAppProcess.StartInfo.UseShellExecute = false;
                botProcess.Start();
                processList.Add(bot.Id, botProcess.Id.ToString());
                System.Threading.Thread.Sleep(5000);
            }
        }

        public static void Start(BotProfile bot)
        {
            Console.WriteLine("start a bot");
            string processid = processList[bot.Id];
            NetNamedPipeBinding netNamedPipeBinding = new NetNamedPipeBinding();
            netNamedPipeBinding.ReceiveTimeout = new TimeSpan(0, 20, 0);
            netNamedPipeBinding.SendTimeout = new TimeSpan(0, 10, 0);
            using (var factory = new ChannelFactory<IBotService>(netNamedPipeBinding, new EndpointAddress(new Uri("net.pipe://localhost/snav/bot/endpoint/" + processid))))
            {
                var botService = factory.CreateChannel();
                botService.StartBotService(new BotEndpoint());
            }
        }
    }
}
